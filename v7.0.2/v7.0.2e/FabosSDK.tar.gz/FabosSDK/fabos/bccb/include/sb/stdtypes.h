/*
 * Copyright (c) 2005 by Brocade Communications Systems, Inc.
 * All rights reserved.
 */

#ifndef _STDTYPES_H_
#define _STDTYPES_H_

#include <stdint.h>
#include <rpc/types.h>

#ifdef __cplusplus
extern "C" {
#endif 

#ifndef __cplusplus
#define false FALSE
#define true TRUE
#endif

#ifdef __cplusplus
}
#endif 

#endif /* _STDTYPES_H_ */
