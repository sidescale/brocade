#ifndef _CSCN_CL_H_
#define _CSCN_CL_H_

#define CS_CN_CL_REPLY_BASE  256

/* client stub function return status */
typedef enum {
    CS_CN_CL_RVAL_SUCCESS = 0,
    CS_CN_CL_RVAL_WAIT,
    CS_CN_CL_RVAL_ERROR
} cs_cn_cl_rval_t;


/* client connnection status */
typedef enum {
    CS_CN_CL_STATUS_CONNECTED = 0,
    CS_CN_CL_STATUS_ERROR,
} cs_cn_cl_cn_status_t;


/* switch function for client api's */
typedef struct {
    void (*status) (void *uctx, cs_cn_cl_cn_status_t status);
    void (*resume) (void *uctx);
} cs_cn_cl_sw_t;

#endif /* _CSCN_CL_H_ */
