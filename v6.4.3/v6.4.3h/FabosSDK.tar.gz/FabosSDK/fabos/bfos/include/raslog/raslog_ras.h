
/* messages define for RAS Module */
#ifndef	__RASLOG_RAS_H__
#define	__RASLOG_RAS_H__
#include  <raslog/raslog.h>
#ifdef RASLOG_CHK
#define RAS_1001  "First failure data capture (FFDC) event occurred."
#else 
#define RAS_1001  ((RAS_RAS_ID << RASLOG_MODID_OFFSET) | 1)
#endif
   
#ifdef RASLOG_CHK
#define RAS_1002  "First failure data capture (FFDC) maximum storage size (%d MB) was reached."
#else 
#define RAS_1002  ((RAS_RAS_ID << RASLOG_MODID_OFFSET) | 2)
#endif
   
#ifdef RASLOG_CHK
#define RAS_1004  "Software 'verify' error detected."
#else 
#define RAS_1004  ((RAS_RAS_ID << RASLOG_MODID_OFFSET) | 3)
#endif
   
#ifdef RASLOG_CHK
#define RAS_1005  "Software 'assert' error detected."
#else 
#define RAS_1005  ((RAS_RAS_ID << RASLOG_MODID_OFFSET) | 4)
#endif
   
#ifdef RASLOG_CHK
#define RAS_2001  "Audit message log is enabled."
#else 
#define RAS_2001  ((RAS_RAS_ID << RASLOG_MODID_OFFSET) | 5)
#endif
   
#ifdef RASLOG_CHK
#define RAS_2002  "Audit message log is disabled."
#else 
#define RAS_2002  ((RAS_RAS_ID << RASLOG_MODID_OFFSET) | 6)
#endif
   
#ifdef RASLOG_CHK
#define RAS_1006  "Support data file (%s) automatically transferred to remote address ' %s '."
#else 
#define RAS_1006  ((RAS_RAS_ID << RASLOG_MODID_OFFSET) | 7)
#endif
   
#ifdef RASLOG_CHK
#define RAS_2003  "Audit message class configuration has been changed to %s."
#else 
#define RAS_2003  ((RAS_RAS_ID << RASLOG_MODID_OFFSET) | 8)
#endif
   
#ifdef RASLOG_CHK
#define RAS_3001  "USB storage device plug-in detected."
#else 
#define RAS_3001  ((RAS_RAS_ID << RASLOG_MODID_OFFSET) | 9)
#endif
   
#ifdef RASLOG_CHK
#define RAS_3002  "USB storage device enabled."
#else 
#define RAS_3002  ((RAS_RAS_ID << RASLOG_MODID_OFFSET) | 10)
#endif
   
#ifdef RASLOG_CHK
#define RAS_3003  "USB storage device was unplugged before it was disabled."
#else 
#define RAS_3003  ((RAS_RAS_ID << RASLOG_MODID_OFFSET) | 11)
#endif
   
#ifdef RASLOG_CHK
#define RAS_3004  "USB storage device disabled."
#else 
#define RAS_3004  ((RAS_RAS_ID << RASLOG_MODID_OFFSET) | 12)
#endif
   
#ifdef RASLOG_CHK
#define RAS_5001  "Message %s caused FFDC event"
#else 
#define RAS_5001  ((RAS_RAS_ID << RASLOG_MODID_OFFSET) | 13 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define RAS_5002  "Out Of Resource  detected by Linux"
#else 
#define RAS_5002  ((RAS_RAS_ID << RASLOG_MODID_OFFSET) | 14 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define RAS_5007  " %s "
#else 
#define RAS_5007  ((RAS_RAS_ID << RASLOG_MODID_OFFSET) | 15 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define RAS_5008  " %s "
#else 
#define RAS_5008  ((RAS_RAS_ID << RASLOG_MODID_OFFSET) | 16 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define RAS_5009  " %s "
#else 
#define RAS_5009  ((RAS_RAS_ID << RASLOG_MODID_OFFSET) | 17 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define RAS_5010  " %s "
#else 
#define RAS_5010  ((RAS_RAS_ID << RASLOG_MODID_OFFSET) | 18 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define RAS_5011  " %s "
#else 
#define RAS_5011  ((RAS_RAS_ID << RASLOG_MODID_OFFSET) | 19 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define RAS_5012  "Software Error:%s."
#else 
#define RAS_5012  ((RAS_RAS_ID << RASLOG_MODID_OFFSET) | 20 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define RAS_5013  "TPA %s message catalog loaded"
#else 
#define RAS_5013  ((RAS_RAS_ID << RASLOG_MODID_OFFSET) | 21 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define RAS_6000  "1250 chip=%d core=%d panic "
#else 
#define RAS_6000  ((RAS_RAS_ID << RASLOG_MODID_OFFSET) | 22 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define RAS_6001  "Read %s FFDC configuration file "
#else 
#define RAS_6001  ((RAS_RAS_ID << RASLOG_MODID_OFFSET) | 23 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define RAS_6002  " %s "
#else 
#define RAS_6002  ((RAS_RAS_ID << RASLOG_MODID_OFFSET) | 24 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define RAS_6003  "1250 chip=%d core=%d RAS is ready"
#else 
#define RAS_6003  ((RAS_RAS_ID << RASLOG_MODID_OFFSET) | 25 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define RAS_7000  "USB storage device enabled mount=%s"
#else 
#define RAS_7000  ((RAS_RAS_ID << RASLOG_MODID_OFFSET) | 26 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define RAS_7001  "USB hotplug device=%s action=%s "
#else 
#define RAS_7001  ((RAS_RAS_ID << RASLOG_MODID_OFFSET) | 27 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define RAS_9000 "Internal Common:%s"
#else
#define RAS_9000  ((RAS_RAS_ID << RASLOG_MODID_OFFSET) | RASLOG_SYS | RASLOG_INTERNAL | 28)
#endif
#ifdef RASLOG_CHK
#define RAS_9001 "Internal Common:%s"
#else
#define RAS_9001  ((RAS_RAS_ID << RASLOG_MODID_OFFSET) | RASLOG_SYS | RASLOG_INTERNAL | 29)
#endif
#ifdef RASLOG_CHK
#define RAS_9002 "Internal Common:%s"
#else
#define RAS_9002  ((RAS_RAS_ID << RASLOG_MODID_OFFSET) | RASLOG_SYS | RASLOG_INTERNAL | 30)
#endif
#ifdef RASLOG_CHK
#define RAS_9003 "Internal Common:%s"
#else
#define RAS_9003  ((RAS_RAS_ID << RASLOG_MODID_OFFSET) | RASLOG_SYS | RASLOG_INTERNAL | 31)
#endif
#ifdef RASLOG_CHK
#define RAS_9004 "Internal Common:%s"
#else
#define RAS_9004  ((RAS_RAS_ID << RASLOG_MODID_OFFSET) | RASLOG_SYS | RASLOG_INTERNAL | 32)
#endif
#ifdef RASLOG_CHK
#define RAS_9005 "Internal Common:%s"
#else
#define RAS_9005  ((RAS_RAS_ID << RASLOG_MODID_OFFSET) | RASLOG_SYS | RASLOG_INTERNAL | 33)
#endif
#endif
