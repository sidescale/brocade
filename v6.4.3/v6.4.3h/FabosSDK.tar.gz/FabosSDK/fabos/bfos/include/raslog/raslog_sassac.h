
/* messages define for SAC Module */
#ifndef	__RASLOG_SAC_H__
#define	__RASLOG_SAC_H__
#include  <raslog/raslog.h>
#ifdef RASLOG_CHK
#define SAC_5001  "%s done"
#else 
#define SAC_5001  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 1 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5002  "Unexpected %s"
#else 
#define SAC_5002  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 2 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5100  "volcfg listen failed "
#else 
#define SAC_5100  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 3 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5101  "voldpe_create: plex dpe alloc failed "
#else 
#define SAC_5101  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 4 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5102  "voldpe_create: vsnap_load_arr alloc failed"
#else 
#define SAC_5102  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 5 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5103  "volevent_ioerr_resolve: SA err resolution dropped because of timeout. Evt_hdl 0x%x"
#else 
#define SAC_5103  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 6 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5104  "volevent_recovery: no such volume"
#else 
#define SAC_5104  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 7 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5105  "volevent_recovery: volume not loaded"
#else 
#define SAC_5105  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 8 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5106  "volevent_ioerr: Unknown error type"
#else 
#define SAC_5106  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 9 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5107  "volevent_io_error: no such volume"
#else 
#define SAC_5107  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 10 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5108  "allocation failure for replace prepare"
#else 
#define SAC_5108  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 11 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5109  "vol_resync_abort_init: cpe_req_ucast failed,"
	     " status 0x%x"
#else 
#define SAC_5109  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 12 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5110  "voldpe_replace_prepare: failed to allocate resources at DPC"
#else 
#define SAC_5110  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 13 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5111  "replace: load of dep device failed"
#else 
#define SAC_5111  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 14 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5112  "voldpe_replace_load_comp: load dep error"
#else 
#define SAC_5112  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 15 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5113  "volume load failed "
#else 
#define SAC_5113  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 16 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5114  "connection handle not valid"
#else 
#define SAC_5114  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 17 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5115  "plex alloc failed "
#else 
#define SAC_5115  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 18 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5116  "volume replace: plex alloc failed "
#else 
#define SAC_5116  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 19 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5117  "volume_attach_rmap failed"
#else 
#define SAC_5117  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 20 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5118  "volume_mir_resync allocation failed"
#else 
#define SAC_5118  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 21 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5119  "resync failed dmap loading"
#else 
#define SAC_5119  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 22 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5120  "failed volume loading"
#else 
#define SAC_5120  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 23 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5121  "Cannot enable rangelock on a non-existent volume"
#else 
#define SAC_5121  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 24 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5122  "Cannot enable rangelock on the volume  %d:%d as it is BUSY"
#else 
#define SAC_5122  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 25 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5123  "Failed to enable rangelock on the volume  %d:%d which is not quiesced"
#else 
#define SAC_5123  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 26 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5124  "Rangelock disable failed as the volume does not exist"
#else 
#define SAC_5124  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 27 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5125  "Failed to disable rangelock on the volume %d:%d which is not quiesced"
#else 
#define SAC_5125  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 28 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5126  "Failed to disable rangelock as the volume %d:%d is not enabled for wrserl"
#else 
#define SAC_5126  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 29 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5127  "Memory allocation failure while acquiring a lock on a volume"
#else 
#define SAC_5127  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 30 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5128  "Failed to release a non-existent lock %d"
#else 
#define SAC_5128  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 31 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5129  "Lock release failed on the non-existent volume"
#else 
#define SAC_5129  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 32 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5130  "resync_mvol_load_done: cpe_req_ucast failed, status 0x%x"
#else 
#define SAC_5130  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 33 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5131  "vol_abort_all_resync: vol_req_alloc failed. Can't handle abort all resync."
#else 
#define SAC_5131  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 34 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5132  "vol_abort_all_resync: cpe_req_ucast failed status 0x%x"
#else 
#define SAC_5132  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 35 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5133  "drl register failed "
#else 
#define SAC_5133  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 36 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5134  "drl_unload: No memory for drl unload req"
#else 
#define SAC_5134  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 37 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5135  "drl_unload: No memory for drl unload req"
#else 
#define SAC_5135  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 38 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5136  "drl_unload: No memory for drl unload req"
#else 
#define SAC_5136  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 39 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5137  "recovery_map_create: could not allocate memory for bitmap"
#else 
#define SAC_5137  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 40 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5138  "recovery_map_create: could not allocate memory for cpe"
#else 
#define SAC_5138  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 41 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5139  "drlcfg listen failed "
#else 
#define SAC_5139  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 42 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5140  "cowcfg listen failed "
#else 
#define SAC_5140  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 43 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5141  "cs_cn_listen failed "
#else 
#define SAC_5141  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 44 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5142  " hash create failed "
#else 
#define SAC_5142  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 45 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5143  "VI Service could not be initialized"
#else 
#define SAC_5143  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 46 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5144  "DPC Management unable to obtain FOS parameters"
#else 
#define SAC_5144  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 47 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5145  "DPC Management Service could not be initialized"
#else 
#define SAC_5145  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 48 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5146  "DPC %d state has changed to ONLINE"
#else 
#define SAC_5146  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 49 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5147  "DPC %d state has changed to OFFLINE"
#else 
#define SAC_5147  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 50 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5148  "copy request on slot %d dpc %d"
#else 
#define SAC_5148  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 51 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5149  "Copy Interface listen failed "
#else 
#define SAC_5149  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 52 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5150  "Extent Interface listen failed "
#else 
#define SAC_5150  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 53 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5151  "No memory for resource map."
#else 
#define SAC_5151  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 54 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5152  "Msg allocation failure"
#else 
#define SAC_5152  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 55 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5153  "Msg allocation failure"
#else 
#define SAC_5153  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 56 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_5154  "Memory allocation failure"
#else 
#define SAC_5154  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | 57 | RASLOG_INTERNAL)
#endif
   
#ifdef RASLOG_CHK
#define SAC_9000 "Internal Common:%s"
#else
#define SAC_9000  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | RASLOG_SYS | RASLOG_INTERNAL | 58)
#endif
#ifdef RASLOG_CHK
#define SAC_9001 "Internal Common:%s"
#else
#define SAC_9001  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | RASLOG_SYS | RASLOG_INTERNAL | 59)
#endif
#ifdef RASLOG_CHK
#define SAC_9002 "Internal Common:%s"
#else
#define SAC_9002  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | RASLOG_SYS | RASLOG_INTERNAL | 60)
#endif
#ifdef RASLOG_CHK
#define SAC_9003 "Internal Common:%s"
#else
#define SAC_9003  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | RASLOG_SYS | RASLOG_INTERNAL | 61)
#endif
#ifdef RASLOG_CHK
#define SAC_9004 "Internal Common:%s"
#else
#define SAC_9004  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | RASLOG_SYS | RASLOG_INTERNAL | 62)
#endif
#ifdef RASLOG_CHK
#define SAC_9005 "Internal Common:%s"
#else
#define SAC_9005  ((RAS_SAC_ID << RASLOG_MODID_OFFSET) | RASLOG_SYS | RASLOG_INTERNAL | 63)
#endif
#endif
